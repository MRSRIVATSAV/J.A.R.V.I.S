package com.pocketvision.ai

import android.net.Uri
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Inference boundary for the on-device model.
 *
 * Production implementation must call a native llama.cpp multimodal binding,
 * pass the image URI/decoded pixels through its vision path, and emit tokens.
 * Do not implement this by sending data to a remote API: this app is designed
 * for offline-only use.
 */
interface LocalModelEngine {
    val isModelLoaded: Boolean
    suspend fun loadModel(modelPath: String, projectorPath: String?)
    fun generate(prompt: String, image: Uri?): Flow<String>
    fun unload()
}

/**
 * UI-only placeholder. Replace with a JNI/NDK llama.cpp implementation before
 * calling this a working AI app. It intentionally does not pretend to analyze
 * images.
 */
class NotConnectedModelEngine : LocalModelEngine {
    override val isModelLoaded: Boolean = false

    override suspend fun loadModel(modelPath: String, projectorPath: String?) {
        throw UnsupportedOperationException(
            "Native multimodal inference is not connected yet. See README.md."
        )
    }

    override fun generate(prompt: String, image: Uri?): Flow<String> = flow {
        emit("The chat interface is ready, but the local vision model has not been connected yet. ")
        emit("Integrate llama.cpp multimodal inference and a compatible model + projector to enable offline answers.")
    }

    override fun unload() = Unit
}
