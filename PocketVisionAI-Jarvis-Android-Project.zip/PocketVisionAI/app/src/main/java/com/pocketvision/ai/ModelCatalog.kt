package com.pocketvision.ai

/**
 * Extensible local model registry.
 *
 * Entries are metadata only until a compatible inference backend and model files
 * are installed. Model files should be imported/downloaded separately and checked
 * for compatibility, license, and available memory before loading.
 */
enum class ModelCapability { TEXT, VISION, AUDIO }

data class LocalModelDescriptor(
    val id: String,
    val displayName: String,
    val family: String,
    val estimatedFileSize: String,
    val capabilities: Set<ModelCapability>,
    val recommendedFor6GbRam: Boolean,
    val backendId: String,
    val notes: String
)

object ModelCatalog {
    val builtInCandidates = listOf(
        LocalModelDescriptor(
            id = "smolvlm-500m",
            displayName = "SmolVLM 500M",
            family = "SmolVLM",
            estimatedFileSize = "Varies by quantization",
            capabilities = setOf(ModelCapability.TEXT, ModelCapability.VISION),
            recommendedFor6GbRam = true,
            backendId = "llama.cpp-multimodal",
            notes = "Candidate for initial benchmarking; confirm exact GGUF and projector compatibility."
        ),
        LocalModelDescriptor(
            id = "moondream2",
            displayName = "Moondream 2",
            family = "Moondream",
            estimatedFileSize = "Varies by build",
            capabilities = setOf(ModelCapability.TEXT, ModelCapability.VISION),
            recommendedFor6GbRam = true,
            backendId = "compatible-vision-backend",
            notes = "Lightweight vision candidate; verify support in the selected Android runtime."
        ),
        LocalModelDescriptor(
            id = "internvl3-1b",
            displayName = "InternVL3 1B",
            family = "InternVL",
            estimatedFileSize = "Varies by quantization",
            capabilities = setOf(ModelCapability.TEXT, ModelCapability.VISION),
            recommendedFor6GbRam = false,
            backendId = "llama.cpp-multimodal",
            notes = "Future candidate; benchmark memory and image support before enabling."
        ),
        LocalModelDescriptor(
            id = "text-model-import",
            displayName = "Import a text-only model",
            family = "Custom GGUF",
            estimatedFileSize = "User selected",
            capabilities = setOf(ModelCapability.TEXT),
            recommendedFor6GbRam = true,
            backendId = "llama.cpp",
            notes = "Text-only models cannot analyze images unless paired with a supported vision architecture."
        )
    )
}
