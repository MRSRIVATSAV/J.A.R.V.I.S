package com.pocketvision.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private val Ink = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2A)
private val Violet = Color(0xFF9B8CFF)
private val Muted = Color(0xFFAAAEC2)

data class ChatMessage(
    val id: Long,
    val fromUser: Boolean,
    val text: String,
    val image: Uri? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketVisionTheme { PocketVisionScreen() } }
    }
}

@Composable
private fun PocketVisionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun PocketVisionScreen() {
    var prompt by remember { mutableStateOf("") }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> selectedImage = uri }

    Column(
        modifier = Modifier.fillMaxSize().background(Ink).padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(Violet),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Memory, contentDescription = null, tint = Ink)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("JARVIS LOCAL", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("PERSONAL ASSISTANT  ·  ON-DEVICE", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            }
            Surface(shape = CircleShape, color = Color(0xFF24382F)) {
                Text("OFFLINE", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    color = Color(0xFF9BE3B5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (messages.isEmpty()) {
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                Text("At your service.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("A private assistant concept for your phone. Attach an image or type a request to begin.",
                    color = Muted, fontSize = 15.sp, lineHeight = 22.sp)
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SuggestionChip("Explain a photo") { prompt = "Explain what is in this image." }
                    SuggestionChip("Solve a question") { prompt = "Solve this step by step." }
                }
                Spacer(Modifier.height(8.dp))
                SuggestionChip("Read my notes") { prompt = "Read and summarize the text in this image." }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (message.fromUser) Alignment.End else Alignment.Start
                    ) {
                        Surface(
                            color = if (message.fromUser) Color(0xFF34304E) else Panel,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 330.dp)
                        ) {
                            Column(Modifier.padding(13.dp)) {
                                message.image?.let {
                                    AsyncImage(it, null, modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp)
                                        .clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
                                    Spacer(Modifier.height(8.dp))
                                }
                                Text(message.text, color = Color.White, lineHeight = 21.sp)
                            }
                        }
                    }
                }
                if (busy) item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Generating locally…", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
            Column(Modifier.padding(10.dp)) {
                selectedImage?.let { uri ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(uri, null, modifier = Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(10.dp))
                        Text("Image attached", color = Muted, modifier = Modifier.weight(1f))
                        IconButton(onClick = { selectedImage = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Remove image", tint = Muted)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { imagePicker.launch("image/*") }) {
                        Icon(Icons.Default.Image, contentDescription = "Upload image", tint = Violet)
                    }
                    BasicTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(Violet),
                        decorationBox = { inner ->
                            Box {
                                if (prompt.isEmpty()) Text("Ask about an image…", color = Muted, fontSize = 15.sp)
                                inner()
                            }
                        }
                    )
                    IconButton(
                        enabled = !busy && (prompt.isNotBlank() || selectedImage != null),
                        onClick = {
                            val question = prompt.ifBlank { "Describe this image." }
                            val image = selectedImage
                            messages.add(ChatMessage(System.nanoTime(), true, question, image))
                            prompt = ""
                            selectedImage = null
                            busy = true
                            scope.launch {
                                // UI demonstration only; replace with real model engine.
                                kotlinx.coroutines.delay(350)
                                messages.add(ChatMessage(
                                    System.nanoTime(), false,
                                    "JARVIS UI preview: the local AI engine is not connected yet. Connect a compatible multimodal model to enable real offline answers."
                                ))
                                busy = false
                            }
                        }
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = "Send",
                            tint = if (!busy && (prompt.isNotBlank() || selectedImage != null)) Ink else Muted,
                            modifier = Modifier.clip(CircleShape).background(
                                if (!busy && (prompt.isNotBlank() || selectedImage != null)) Violet else Color(0xFF383A49)
                            ).padding(10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SuggestionChip(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = Panel,
        contentColor = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF343647))
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp), fontSize = 12.sp)
    }
}
