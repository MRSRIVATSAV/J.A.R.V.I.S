package com.pocketvision.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Model manager screen scaffold. Hook this into app navigation when adding
 * native model import/load/delete operations.
 */
@Composable
fun ModelManagerScreen(
    activeModelId: String? = null,
    onChooseModel: (LocalModelDescriptor) -> Unit = {},
    onImportModel: () -> Unit = {}
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Model library", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            "Choose a compatible local model. Entries are candidates until model files and the matching backend are installed.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onImportModel, modifier = Modifier.fillMaxWidth()) {
            Text("Import model files")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(ModelCatalog.builtInCandidates, key = { it.id }) { model ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(model.displayName, style = MaterialTheme.typography.titleMedium)
                        Text("${model.family} · ${model.estimatedFileSize}")
                        Text(
                            model.capabilities.joinToString(" · ") { it.name.lowercase() },
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(model.notes, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        Row {
                            if (activeModelId == model.id) {
                                Text("Selected", color = MaterialTheme.colorScheme.primary)
                            } else {
                                OutlinedButton(onClick = { onChooseModel(model) }) {
                                    Text("Select")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
