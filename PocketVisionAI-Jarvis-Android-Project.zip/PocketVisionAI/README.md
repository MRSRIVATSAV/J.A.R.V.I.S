# Pocket Vision AI — Android starter project

This is a native Android Studio starter for an offline image-chat app. It includes:
- Jetpack Compose chat UI
- Android photo picker
- Image preview and prompt input
- Streaming-style token display interface
- A clear inference adapter boundary for integrating llama.cpp

## Important status
This starter is **not yet a functioning offline LLM APK**. The UI and image-selection flow are implemented, but `LocalModelEngine` is an interface with a demo placeholder. Actual on-device inference requires integrating a compatible llama.cpp Android native build and a vision model + its projector. I am not labeling a demo APK as a working AI app.

## Build
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. For a debug build, Android Studio normally writes the APK under `app/build/outputs/apk/debug/`.

## Device model
This project targets `arm64-v8a` phones and Android 8.0+ (API 26). Please test on your actual phone; 6 GB total RAM limits model size and context.

## Offline model integration plan
Use a llama.cpp Android native integration and a supported quantized vision GGUF model. Vision models may need both a language-model GGUF and a multimodal projector (`mmproj`). See:
- https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- https://github.com/ggml-org/llama.cpp/blob/master/docs/multimodal.md

For a 6 GB phone, benchmark a compact model such as SmolVLM-500M-Instruct or another supported compact vision model first. Model compatibility and memory use must be verified before shipping. Download model files on Wi-Fi from a trusted source, verify license and hashes, then store them in app-private storage. After setup, inference can run offline.

## Privacy
The manifest does not request INTERNET permission. This UI scaffold has no network code. Model download should be an explicit setup step added later, or users can import model files locally.


## Future model support
The project includes `ModelCatalog.kt`, a metadata registry designed for future model choices. Add a new descriptor for each model family, then implement its matching backend adapter. Do not expose a model as loadable merely because it appears in the catalog: validate its file format, architecture, projector, license, and RAM requirements first.

Candidate families to evaluate over time:
- SmolVLM (compact vision-language)
- Moondream (compact vision-language)
- InternVL small variants (vision-language; benchmark carefully)
- Text-only GGUF models for chat, clearly marked as not image-capable
- Audio models later, if the app grows to support voice

Model management should eventually include:
- Import model and projector files through Android's document picker
- Display file size, capabilities, license, backend compatibility, and estimated memory
- Set active model and remember selection locally
- Remove model files and show storage used
- Benchmark prompt processing and tokens/second
- Warn before loading models likely to exceed available memory

Do not silently download models in the background. For a strictly offline app, allow importing files from local storage; if a future download feature is added, make it an explicit online setup step.


## Build an APK using GitHub Actions
This project includes `.github/workflows/build-apk.yml`. To use it:
1. Create a GitHub repository and upload/commit the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build Pocket Vision APK** (or push to `main`/`master`).
4. Download the `PocketVisionAI-debug-apk` artifact from the workflow run.

This workflow builds the current UI starter. It does **not** make the placeholder into a functioning AI model. Real offline answers require completing and testing the native multimodal inference integration first.
